# Portfolio (Next.js 15 + Prisma + next-intl, AR/EN)
## Run
1. `cp .env.example .env` and fill values (Neon/Supabase Postgres URL, `openssl rand -base64 32` for NEXTAUTH_SECRET)
2. `npm install && npm run db:push && npm run seed && npm run dev`
3. Site: http://localhost:3000 — Admin: /ar/admin (sign in via /api/auth/signin)
## Deploy (Vercel)
Import repo, add all `.env` variables, set NEXTAUTH_URL to your domain, deploy.
## Done in this scaffold
Full Prisma schema, i18n RTL/LTR, dark mode default, secure headers, credentials auth with roles, home page, admin stats.
## Next steps
Projects/Blog/Contact pages, admin CRUD, analytics tracking, Google OAuth, 2FA, Resend form, sitemap/robots.
