import createNextIntlPlugin from "next-intl/plugin";
const withIntl = createNextIntlPlugin("./src/i18n/request.ts");
export default withIntl({ async headers(){ return [{ source:"/(.*)", headers:[
  {key:"Strict-Transport-Security",value:"max-age=63072000; includeSubDomains"},
  {key:"X-Frame-Options",value:"DENY"},{key:"X-Content-Type-Options",value:"nosniff"}]}]; }});
