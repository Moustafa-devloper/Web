import type { NextAuthOptions } from "next-auth"; import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs"; import { z } from "zod"; import { prisma } from "./prisma";
export const authOptions: NextAuthOptions = {
  session:{strategy:"jwt"}, pages:{signIn:"/api/auth/signin"},
  providers:[Credentials({ credentials:{email:{},password:{}}, async authorize(c){
    const v = z.object({email:z.string().email(),password:z.string().min(8)}).safeParse(c);
    if(!v.success) return null;
    const u = await prisma.user.findUnique({where:{email:v.data.email}});
    if(!u?.password || !(await bcrypt.compare(v.data.password,u.password))) return null;
    return {id:u.id,email:u.email,name:u.name,role:u.role} as any; }})],
  callbacks:{ jwt({token,user}){ if(user)(token as any).role=(user as any).role; return token; },
    session({session,token}){ (session.user as any).role=(token as any).role; return session; } }
};
