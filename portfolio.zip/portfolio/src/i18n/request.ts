import { getRequestConfig } from "next-intl/server"; import { routing } from "./routing";
export default getRequestConfig(async ({ requestLocale }) => {
  let l = await requestLocale;
  if (!l || !routing.locales.includes(l as any)) l = routing.defaultLocale;
  return { locale: l, messages: (await import(`../../messages/${l}.json`)).default };
});
