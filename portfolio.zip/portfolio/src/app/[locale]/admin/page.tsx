import { getServerSession } from "next-auth"; import { redirect } from "next/navigation";
import { getTranslations } from "next-intl/server"; import { authOptions } from "@/lib/auth"; import { prisma } from "@/lib/prisma";
export const dynamic = "force-dynamic";
export default async function Admin(){
  const s = await getServerSession(authOptions);
  if(!s || (s.user as any).role!=="ADMIN") redirect("/api/auth/signin");
  const t = await getTranslations("admin");
  const [views,unread] = await Promise.all([prisma.pageView.count(), prisma.message.count({where:{read:false}})]);
  return (<main className="mx-auto max-w-5xl p-8"><h1 className="text-3xl font-bold">{t("title")}</h1>
    <div className="mt-6 grid gap-4 md:grid-cols-2">
      <div className="rounded-2xl bg-white/5 p-6"><p>{t("visits")}</p><b className="text-4xl">{views}</b></div>
      <div className="rounded-2xl bg-white/5 p-6"><p>{t("unread")}</p><b className="text-4xl">{unread}</b></div></div></main>);
}
