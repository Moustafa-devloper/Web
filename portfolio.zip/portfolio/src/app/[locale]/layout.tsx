import "../globals.css"; import { NextIntlClientProvider } from "next-intl";
import { getMessages } from "next-intl/server";
export default async function L({children,params}:{children:React.ReactNode;params:Promise<{locale:string}>}){
  const {locale} = await params;
  return (<html lang={locale} dir={locale==="ar"?"rtl":"ltr"} className="dark"><body className="bg-slate-950 text-slate-100">
    <NextIntlClientProvider messages={await getMessages()}>{children}</NextIntlClientProvider></body></html>);
}
