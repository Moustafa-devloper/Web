import { getTranslations, getLocale } from "next-intl/server"; import { prisma } from "@/lib/prisma";
export const dynamic = "force-dynamic";
export default async function Home(){
  const t = await getTranslations(); const l = await getLocale();
  const projects = await prisma.project.findMany({where:{published:true},orderBy:{order:"asc"},take:6});
  return (<main className="mx-auto max-w-5xl px-6 py-20">
    <section className="rounded-3xl border border-white/10 bg-gradient-to-br from-indigo-500/20 to-fuchsia-500/10 p-12 backdrop-blur">
      <h1 className="text-5xl font-bold">{t("hero.title")}</h1>
      <p className="mt-4 text-lg text-slate-300">{t("hero.sub")}</p>
      <a href="#projects" className="mt-8 inline-block rounded-full bg-indigo-500 px-6 py-3 font-medium">{t("hero.cta")}</a></section>
    <h2 id="projects" className="mt-16 text-2xl font-semibold">{t("projects")}</h2>
    <div className="mt-6 grid gap-4 md:grid-cols-2">{projects.map(p=>(
      <article key={p.id} className="rounded-2xl border border-white/10 bg-white/5 p-6">
        <h3 className="text-xl font-medium">{l==="ar"?p.titleAr:p.titleEn}</h3>
        <p className="mt-2 text-slate-400">{l==="ar"?p.descAr:p.descEn}</p></article>))}</div>
  </main>);
}
