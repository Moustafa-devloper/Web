import { PrismaClient } from "@prisma/client"; import bcrypt from "bcryptjs";
const p = new PrismaClient();
async function main() {
  await p.user.upsert({ where:{email:process.env.ADMIN_EMAIL!}, update:{},
    create:{email:process.env.ADMIN_EMAIL!, name:"Admin", role:"ADMIN",
      password: await bcrypt.hash(process.env.ADMIN_PASSWORD!,12)} });
  await p.project.upsert({ where:{slug:"demo"}, update:{}, create:{slug:"demo",
    titleAr:"مشروع تجريبي", titleEn:"Demo Project", descAr:"وصف تجريبي", descEn:"Sample description", tags:["Next.js","Prisma"]} });
  await p.skill.createMany({ data:[{name:"TypeScript",level:90},{name:"React",level:85}], skipDuplicates:true });
}
main().finally(()=>p.$disconnect());
